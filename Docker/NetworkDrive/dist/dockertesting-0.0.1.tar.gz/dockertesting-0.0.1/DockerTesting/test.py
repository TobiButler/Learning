# simple script for testing docker
import pandas as pd
import pyodbc
import numpy as np
import os
print(os.environ)


print(115)

with open(r"\\Asasprdvm01\acct\ACCOUNTABILITY\2024\Tobias\Misc\test.txt", 'r') as file:
    s = file.read()
print(s)
